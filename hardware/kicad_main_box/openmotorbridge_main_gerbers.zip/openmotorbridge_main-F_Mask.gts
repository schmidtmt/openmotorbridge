%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-24T09:31:30+02:00*%
%TF.ProjectId,openmotorbridge_main,6f70656e-6d6f-4746-9f72-627269646765,v8.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-24 09:31:30*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,6.100000*%
G04 APERTURE END LIST*
D10*
%TO.C,H1*%
X118220238Y-74848250D03*
%TD*%
%TO.C,H3*%
X118220238Y-123848250D03*
%TD*%
%TO.C,H4*%
X197220238Y-123848250D03*
%TD*%
%TO.C,H2*%
X197220238Y-74848250D03*
%TD*%
M02*

%TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*%
%TF.CreationDate,2026-08-24T09:31:31+02:00*%
%TF.ProjectId,openmotorbridge_rear_pod3,6f70656e-6d6f-4746-9f72-627269646765,v8.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-08-24 09:31:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,5.500000*%
G04 APERTURE END LIST*
D10*
%TO.C,*%
X147075012Y-102075012D03*
%TD*%
%TO.C,*%
X147075012Y-73075012D03*
%TD*%
%TO.C,*%
X103075012Y-102075012D03*
%TD*%
%TO.C,*%
X103075012Y-73075012D03*
%TD*%
M02*

OpenMotorBridge Smart Fairing Controller (PCBA 05)
4-Layer FR4 TG150 ENIG, 65x42mm, JLC04161H-7628 stackup
Microchip USB2512B, TI TPS2051B, ESP32-C3, Knowles SPH0645
